<!DOCTYPE html>
<html>
<head>
<title>Login Page</title>
</head>
<body>
	<h1>Hello! Please Login</h1>
	<form method="post" action="checkLoginCreds.jsp">
		Username: <input type="text" name="username"> <br />
		Password: <input type="text" name="password"> <br /> 
		<input type="submit" value="submit" />
	</form>
</body>
</html>